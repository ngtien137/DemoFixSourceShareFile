package com.leaf.music

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.os.Bundle
import android.os.IBinder
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import androidx.navigation.ui.setupWithNavController
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.leaf.music.model.Song
import com.leaf.music.repository.SongRepository
import com.leaf.music.ui.SongViewModel
import com.leaf.music.ui.SongViewModelFactory
import com.leaf.music.ui.fragment.PlayerFragment
import com.leaf.music.util.Constants.PREF_NAME
import com.leaf.music.util.MusicPlayerRemote
import com.leaf.music.util.PlayerHelper
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.activity.navController
import org.monora.uprotocol.client.android.app.Activity

open class MusicActivity : Activity() {

    private lateinit var bottomSheetBehavior: BottomSheetBehavior<FrameLayout>
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var dimBackground: View
    private lateinit var miniPlayerFragment: View
    private lateinit var bottomNavigationView: BottomNavigationView

    private val currentSong get() = PlayerHelper.getCurrentSong(sharedPreferences)

    private val panelState: Int
        get() = bottomSheetBehavior.state

    private val bottomSheetCallback = object : BottomSheetBehavior.BottomSheetCallback() {
        override fun onStateChanged(bottomSheet: View, newState: Int) {
            when (newState) {
                BottomSheetBehavior.STATE_COLLAPSED -> {
                    dimBackground.visibility = View.GONE
                }
                else -> {
                }
            }
        }

        override fun onSlide(bottomSheet: View, slideOffset: Float) {
            setMiniPlayerAlpha(slideOffset)
            setBottomNavigationViewTransition(slideOffset)
            dimBackground.visibility = View.VISIBLE
            dimBackground.alpha = slideOffset
        }
    }

    private var serviceToken: MusicPlayerRemote.ServiceToken? = null
    private lateinit var viewModel: SongViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        dimBackground = findViewById(R.id.dimBackground)
        val slidingPanel = findViewById<FrameLayout>(R.id.slidingPanel)
        miniPlayerFragment = findViewById(R.id.miniPlayerFragment)
        bottomNavigationView = findViewById(R.id.bottomNavigationView)

        val repository = SongRepository(this)
        val viewModelFactory = SongViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(SongViewModel::class.java)

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                reloadPlayerFragment()
                if (MusicPlayerRemote.playerService?.mediaPlayer == null && currentSong != null) {
                    MusicPlayerRemote.playerService?.initMediaPlayer(currentSong!!.id)
                    viewModel.songLiveData.observe(this@MusicActivity, {
                        if (it.isNotEmpty()) {
                            MusicPlayerRemote.sendAllSong(it as MutableList<Song>, -1)
                        } else {
                            MusicPlayerRemote.sendAllSong(
                                emptyList<Song>() as MutableList<Song>,
                                -1
                            )
                        }
                    })
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
            }
        })

        setUpBottomNavigationNavController()

        bottomSheetBehavior = BottomSheetBehavior.from(slidingPanel)
        bottomSheetBehavior.addBottomSheetCallback(bottomSheetCallback)

        miniPlayerFragment.setOnClickListener {
            expandPanel()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }

        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        bottomSheetBehavior.removeBottomSheetCallback(bottomSheetCallback)
        //MusicPlayerRemote.unbindFromService(serviceToken)
    }

    override fun onBackPressed() {
        if (!handleBackPress()) super.onBackPressed()
    }

    open fun handleBackPress(): Boolean {
        if (panelState == BottomSheetBehavior.STATE_EXPANDED) {
            collapsePanel()
            return true
        }
        return false
    }

    private fun collapsePanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        setMiniPlayerAlpha(0f)
    }

    private fun expandPanel() {
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        setMiniPlayerAlpha(1f)
    }

    private val playerFragment = PlayerFragment()
    fun reloadPlayerFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.playerFragmentContainer, playerFragment)
            .commit()
    }

    private fun setMiniPlayerAlpha(slideOffset: Float) {
        playerFragment.setMiniPlayerAlpha(slideOffset)
        val alpha = 1 - slideOffset
        miniPlayerFragment.alpha = alpha
        miniPlayerFragment.visibility = if (alpha == 0f) View.GONE else View.VISIBLE
    }

    private fun setBottomNavigationViewTransition(slideOffset: Float) {
        bottomNavigationView.translationY = slideOffset * 500
    }

    private fun setUpBottomNavigationNavController() {
        bottomNavigationView.setupWithNavController(navController(R.id.musicNavHostFragment))
    }
}