package com.leaf.music.model

data class Song(
    val id: Long,
    val name: String,
    val path: String,
    val artistName: String?,
    val albumName: String?,
    val duration: Long,
    val albumArt: String
)