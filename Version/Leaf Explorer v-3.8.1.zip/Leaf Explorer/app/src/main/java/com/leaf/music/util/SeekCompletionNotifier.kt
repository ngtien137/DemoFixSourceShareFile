package com.leaf.music.util

interface SeekCompletionNotifier {
    fun onSeekComplete()
}