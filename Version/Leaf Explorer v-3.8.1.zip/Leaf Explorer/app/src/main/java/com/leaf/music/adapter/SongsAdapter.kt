package com.leaf.music.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.leaf.music.model.Song
import com.leaf.music.helper.MusicLibraryHelper
import com.leaf.music.model.Music
import com.leaf.music.util.MusicPlayerRemote
import me.zhanghai.android.fastscroll.PopupTextProvider
import org.monora.uprotocol.client.android.GlideApp
import org.monora.uprotocol.client.android.R
import java.util.*
import kotlin.collections.ArrayList

class SongsAdapter(
    val context: Context,
    private var songList: MutableList<Music>
) : RecyclerView.Adapter<SongsAdapter.SongsViewHolder>(), PopupTextProvider {

    private lateinit var songPlay: MutableList<Song>

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongsViewHolder {
        return SongsViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_songs, parent, false)
        )
    }

    override fun onBindViewHolder(holder: SongsViewHolder, position: Int) {

        val songs = songList[position]
        holder.songName.text = songs.title
        holder.albumName.text = String.format(Locale.getDefault(), "%s • %s",
            songs.artist,
            songs.album)

        if(songs.dateAdded.equals(-1)) {
            holder.songHistory.visibility = View.GONE
        } else {
            holder.songHistory.text = String.format(
                Locale.getDefault(), "%s • %s",
                MusicLibraryHelper.formatDuration(songs.duration),
                MusicLibraryHelper.formatDate(songs.dateAdded)
            )
        }

        GlideApp.with(holder.albumArt.context)
            .load(songs.albumArt)
            .placeholder(R.drawable.baseline_album_24)
            .into(holder.albumArt)

        holder.itemView.setOnClickListener {
            insertData()
            MusicPlayerRemote.sendAllSong(songPlay, position)
        }
    }

    private fun insertData() {
        songPlay = ArrayList()
        for (path in songList) {
            loadSongsFolderData(path)
        }
    }

    private fun loadSongsFolderData(path: Music) {
        songPlay.add(Song(path.id, path.title, path.albumArt, path.artist, path.album, path.duration, path.albumArt))
    }

    override fun getItemCount(): Int {
        return songList.size
    }

    override fun getPopupText(position: Int): String {
        val songName = songList[position].title
        return getSectionName(songName)
    }

    class SongsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val songName: TextView = view.findViewById(R.id.song_name)
        val albumName: TextView = view.findViewById(R.id.song_album)
        val songHistory: TextView = view.findViewById(R.id.song_history)
        val albumArt: ImageView = view.findViewById(R.id.album_art)
    }

    fun updateSongList(songList: List<Music>) {
        this.songList = ArrayList(songList)
        notifyDataSetChanged()
    }

    private fun getSectionName(musicMediaTitle: String?): String {
        var songName = musicMediaTitle
        return try {
            if (TextUtils.isEmpty(songName)) {
                return ""
            }
            songName = songName!!.trim { it <= ' ' }.toLowerCase(Locale.ROOT)
            if (songName.startsWith("the ")) {
                songName = songName.substring(4)
            } else if (songName.startsWith("a ")) {
                songName = songName.substring(2)
            }
            if (songName.isEmpty()) {
                ""
            } else songName.substring(0, 1).toUpperCase(Locale.ROOT)
        } catch (e: Exception) {
            ""
        }
    }
}