package com.leaf.music.ui.fragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.leaf.music.MPConstants
import com.leaf.music.adapter.SongsFolderAdapter
import com.leaf.music.views.ScrollingViewOnApplyWindowInsetsListener
import me.zhanghai.android.fastscroll.FastScroller
import me.zhanghai.android.fastscroll.FastScrollerBuilder
import org.monora.uprotocol.client.android.R
import com.leaf.music.model.Folder
import com.leaf.music.model.SongsFolderModel
import com.leaf.music.model.Music

class FolderSongsFragment : Fragment(R.layout.fragment_songs_folder) {

    private lateinit var adapter: SongsFolderAdapter
    private lateinit var rvSongs: RecyclerView
    private var folderList: List<Folder> = ArrayList()
    private lateinit var mArrayList: ArrayList<SongsFolderModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        folderList = MPConstants.getFolders(MPConstants.getSongs(context, false), false)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvSongs = view.findViewById(R.id.rvSongs)

        rvSongs.layoutManager = LinearLayoutManager(context)
        adapter = SongsFolderAdapter(requireContext(), mutableListOf())
        rvSongs.adapter = adapter

        val fastScroller = createFastScroller(rvSongs)

        rvSongs.setOnApplyWindowInsetsListener(
            ScrollingViewOnApplyWindowInsetsListener(rvSongs, fastScroller)
        )

        insertData()
        adapter.updateSongList(mArrayList)
    }

    private fun insertData() {
        mArrayList = ArrayList()
        for (path in folderList) {
            loadSongsFolderData(path.title, path.music.size, path.music)
        }
    }

    private fun loadSongsFolderData(folderName: String, size: Int, loadSongsList: MutableList<Music>) {
        val folderDetails = "("+size+")" + " songs"
        if (context != null) {
            mArrayList.add(SongsFolderModel(1, folderName, folderDetails, loadSongsList))
        }
    }

    private fun createFastScroller(recyclerView: RecyclerView): FastScroller {
        return FastScrollerBuilder(recyclerView).useMd2Style().build()
    }
}