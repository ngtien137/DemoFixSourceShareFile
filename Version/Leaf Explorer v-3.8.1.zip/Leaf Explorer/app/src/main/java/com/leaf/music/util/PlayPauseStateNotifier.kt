package com.leaf.music.util

interface PlayPauseStateNotifier {
    fun onPlayPauseStateChange()
}