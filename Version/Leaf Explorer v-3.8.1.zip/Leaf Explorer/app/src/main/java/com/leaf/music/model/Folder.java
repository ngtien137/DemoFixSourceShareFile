package com.leaf.music.model;

import android.os.Parcel;
import android.os.Parcelable;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import java.util.List;

public class Folder implements Parcelable {
    public static final Creator<Folder> CREATOR = new Creator<Folder>() {
        @Override
        public Folder createFromParcel(Parcel in) {
            return new Folder(in);
        }

        @Override
        public Folder[] newArray(int size) {
            return new Folder[size];
        }
    };
    public String title;
    public List<Music> music;

    public Folder(String title, List<Music> music) {
        this.title = ifNull(title);
        this.music = music;
    }

    protected Folder(Parcel in) {
        title = in.readString();
        music = new ArrayList<>();
        in.readTypedList(music, Music.CREATOR);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeTypedList(music);
    }

    @NotNull
    @Override
    public String toString() {
        return "Folder{" +
                "title='" + title + '\'' +
                ", music=" + music +
                '}';
    }

    public static String ifNull(String val) {
        return val == null ? "" : val;
    }
}
