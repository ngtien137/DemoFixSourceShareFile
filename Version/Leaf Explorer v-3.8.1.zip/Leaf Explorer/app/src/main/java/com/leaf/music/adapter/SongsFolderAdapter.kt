package com.leaf.music.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import org.monora.uprotocol.client.android.R
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.leaf.music.model.SongsFolderModel

class SongsFolderAdapter(
    val context: Context,
    private var songList: MutableList<SongsFolderModel>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return when (viewType) {
            VIEW_TYPE_FOLDER -> {
                FolderViewHolder(
                    LayoutInflater.from(parent.context)
                        .inflate(R.layout.layout_song_folder, parent, false)
                )
            }
            else -> throw UnsupportedOperationException()
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val itemModel = songList[position]

        when (itemModel.viewType) {
            VIEW_TYPE_FOLDER -> {
                (holder as FolderViewHolder).folderName.text = itemModel.folderName

                if (itemModel.folderUrl == "") {
                    holder.folderUrl.text = itemModel.folderUrl
                } else {
                    holder.folderUrl.visibility = View.GONE
                }

                holder.folderRecyclerView.setHasFixedSize(true)
                holder.folderRecyclerView.layoutManager = LinearLayoutManager(context)
                val adapter = SongsAdapter(context, itemModel.loadSongsList)
                holder.folderRecyclerView.adapter = adapter

                holder.itemView.setOnClickListener {
                    if (holder.folderRecyclerView.visibility == View.VISIBLE) {
                        holder.folderRecyclerView.visibility = View.GONE
                        holder.btnExpand.setImageResource(R.drawable.ic_navigate_before_white_24dp)
                    } else {
                        holder.folderRecyclerView.visibility = View.VISIBLE
                        holder.btnExpand.setImageResource(R.drawable.ic_arrow_down_24dp)
                    }
                }

            }
        }
    }

    override fun getItemCount(): Int {
        return songList.size
    }

    class FolderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val folderName: TextView = view.findViewById(R.id.folderName)
        val folderUrl: TextView = view.findViewById(R.id.folderUrl)
        val btnExpand: ImageView = view.findViewById(R.id.btn_expand)
        val folderRecyclerView: RecyclerView = view.findViewById(R.id.folder_recycler_view)
    }

    fun updateSongList(songList: List<SongsFolderModel>) {
        this.songList = ArrayList(songList)
        notifyDataSetChanged()
    }

    companion object {
        const val VIEW_TYPE_FOLDER = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (songList[position].viewType) {
            VIEW_TYPE_FOLDER -> {
                VIEW_TYPE_FOLDER
            }
            else -> -1
        }
    }
}