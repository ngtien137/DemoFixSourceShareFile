package com.leaf.music.model

data class SongsFolderModel(
    val viewType: Int,
    val folderName: String,
    val folderUrl: String,
    val loadSongsList: MutableList<Music>
)