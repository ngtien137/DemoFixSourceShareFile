package org.monora.uprotocol.client.android.fragment.explorer

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.activityViewModels
import com.genonbeta.android.framework.util.Files
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.model.FileModel
import org.monora.uprotocol.client.android.viewmodel.SharingSelectionViewModel

class FileDetailsDialog : BottomSheetDialogFragment() {
    private val selectionViewModel: SharingSelectionViewModel by activityViewModels()

    private var fileList = ArrayList<FileModel>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.layout_file_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        selectionViewModel.selectionState.observe(this) {
            for (data in it) {
                if (data is FileModel) {
                    getFileModel(data)
                }

                if (fileList.size == it.size) {
                    actionDetails(view)
                }
            }
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        selectionViewModel.externalState.value = Unit
    }

    private fun getFileModel(fileModel: FileModel) {
        fileList.add(fileModel)
    }

    private fun actionDetails(view: View) {
        val name: TextView = view.findViewById(R.id.name)
        val path: TextView = view.findViewById(R.id.path)
        val size: TextView = view.findViewById(R.id.size)
        val date: TextView = view.findViewById(R.id.date)
        val content: TextView = view.findViewById(R.id.content)

        if (fileList.size == 1) {
            for (fileModel in fileList) {
                name.text = fileModel.file.getName()
                path.text = fileModel.file.parent?.getUri()?.path ?: "NULL"
                val sizeText by lazy {
                    Files.formatLength(fileModel.file.getLength(), false)
                }
                size.text = sizeText
                date.text = "----"
                content.text = "----"
            }
        }
    }
}