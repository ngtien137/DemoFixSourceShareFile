package org.monora.uprotocol.client.android.model

data class CategoryModel(val name: String, val info: String, val image: Int)