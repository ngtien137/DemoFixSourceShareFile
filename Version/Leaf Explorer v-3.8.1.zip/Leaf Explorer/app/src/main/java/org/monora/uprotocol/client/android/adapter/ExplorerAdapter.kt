package org.monora.uprotocol.client.android.adapter

import android.content.Context
import android.util.SparseBooleanArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SortedList
import androidx.recyclerview.widget.SortedListAdapterCallback
import com.genonbeta.android.framework.io.DocumentFile
import com.genonbeta.android.framework.util.Files
import org.monora.uprotocol.client.android.GlideApp
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.databinding.LayoutFileExplorerBinding
import org.monora.uprotocol.client.android.model.FileModel
import org.monora.uprotocol.client.android.util.HomeFragHelper
import org.monora.uprotocol.client.android.util.MimeIcons

class ExplorerAdapter(val context: Context, private val mListener: Listener) : RecyclerView.Adapter<ViewHolder>() {
    private var mPath: DocumentFile? = null
    private var selectedItems = SparseBooleanArray()

    private val fileSortedList: SortedList<DocumentFile> =
        SortedList(DocumentFile::class.java, object : SortedListAdapterCallback<DocumentFile>(this) {
            override fun compare(o1: DocumentFile, o2: DocumentFile): Int {
                val isDirectory1: Boolean = o1.isDirectory()

                val isDirectory2: Boolean = o2.isDirectory()

                if (isDirectory1 != isDirectory2) return if (isDirectory1) -1 else +1

                return HomeFragHelper.compareName(o1, o2)
            }

            override fun areContentsTheSame(oldItem: DocumentFile, newItem: DocumentFile): Boolean =
                oldItem == newItem

            override fun areItemsTheSame(item1: DocumentFile, item2: DocumentFile): Boolean =
                item1 == item2
        })

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolderExplorer(LayoutFileExplorerBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val itemModel = fileSortedList[position]

        val indexCount = when {
            itemModel.isDirectory() -> itemModel.listFiles(context).size
            else -> 0
        }
        val fileModel = FileModel(itemModel, indexCount)

        (holder as ViewHolderExplorer).title.text = fileModel.file.getName()

        val sizeText by lazy {
            Files.formatLength(fileModel.file.getLength(), false)
        }
        val secondaryText = if (fileModel.file.isDirectory()) {
            context.resources.getQuantityString(R.plurals.files, fileModel.indexCount, fileModel.indexCount)
        } else {
            sizeText
        }

        holder.secondaryText.text = secondaryText

        val icon = if (fileModel.file.isDirectory()) {
            R.drawable.ic_folder_white_24dp
        } else {
            MimeIcons.loadMimeIcon(fileModel.file.getType())
        }
        GlideApp.with(holder.icon.context)
            .load(icon)
            .into(holder.icon)

        holder.root.root.setOnClickListener {
            if (anySelected()) {
                clearSelection()
            }
            mListener.onPathClicked(fileModel.file)
        }
        holder.root.selection.setOnClickListener {
            setSelected(it, position, fileModel)
        }
        holder.root.selection.isSelected = fileModel.isSelected
        holder.root.executePendingBindings()

    }

    override fun getItemCount(): Int {
        return fileSortedList.size()
    }

    class ViewHolderExplorer(binding: LayoutFileExplorerBinding) : RecyclerView.ViewHolder(binding.root) {
        var root: LayoutFileExplorerBinding = binding
        var icon: ImageView = binding.icon
        var title: TextView = binding.title
        var secondaryText: TextView = binding.secondaryText
    }

    private fun anySelected(): Boolean {
        return selectedItems.size() > 0
    }

    fun setSelected(it: View, position: Int, fileModel: FileModel) {
        if (getSelected(position)) {
            selectedItems.delete(position)
        } else {
            selectedItems.append(position, true)
        }

        fileModel.isSelected = !fileModel.isSelected
        it.isSelected = fileModel.isSelected
       // notifyItemChanged(position)
        mListener.onSelection()
    }

    private fun getSelected(position: Int): Boolean {
        return selectedItems.get(position)
    }

    private fun clearSelection() {
        selectedItems.clear()

        mListener.onSelection()
    }

    fun getSelectedItems(): ArrayList<DocumentFile> {
        val selectedList = ArrayList<DocumentFile>()

        for (i in 0 until itemCount) {
            if (getSelected(i)) {
                selectedList.add(get(i))
            }
        }
        return selectedList
    }

    fun get(position: Int): DocumentFile {
        return fileSortedList.get(position)
    }

    private fun fileManager() {
        val path: DocumentFile = getPath()

        val fileIndex = path.listFiles(context)

        if (fileIndex.isNotEmpty()) {
            for (file in fileIndex) {
                fileSortedList.add(file)
            }
        }
    }

    fun onRefresh() {
        fileSortedList.clear()
        fileManager()
        notifyDataSetChanged()
    }

    fun getPath(): DocumentFile {
        return mPath!!
    }

    fun goPath(path: DocumentFile) {
        mPath = path
        onRefresh()
    }

    interface Listener {
        fun onPathClicked(path: DocumentFile)

        fun onSelection()
    }

}