package org.monora.uprotocol.client.android.listener

interface HomeListener {
    fun onShareClicked(button: String)
}