package org.monora.uprotocol.client.android.fragment.explorer

import android.content.ContentResolver
import android.content.Context
import android.content.DialogInterface
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.activityViewModels
import com.genonbeta.android.framework.io.DocumentFile
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.config.AppConfig
import org.monora.uprotocol.client.android.fragment.ExplorerFragment
import org.monora.uprotocol.client.android.model.FileModel
import org.monora.uprotocol.client.android.viewmodel.SharingSelectionViewModel
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

class FileCopyMoveDialog(val listener: Listener) : BottomSheetDialogFragment() {
    private val selectionViewModel: SharingSelectionViewModel by activityViewModels()

    private var fileList = ArrayList<FileModel>()
    private val explorerFragment = ExplorerFragment()
    private var mTotalPaste = 0
    private val copiedItems: MutableList<Uri> = ArrayList()
    private var copyStart = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.layout_file_copy_move, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        selectionViewModel.selectionState.observe(this) {
            for (data in it) {
                if (data is FileModel) {
                    getFileModel(data)
                }

                if (fileList.size == it.size) {
                    actionMain(view)
                }
            }
        }

        val manager = childFragmentManager
        val transaction = manager.beginTransaction()

        transaction.replace(R.id.fragment_explorer, explorerFragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        progressDialog.dismiss()
        selectionViewModel.externalState.value = Unit
    }

    private fun getFileModel(fileModel: FileModel) {
        fileList.add(fileModel)
    }

    private fun actionMain(view: View) {
        val pasteButton: MaterialButton = view.findViewById(R.id.pasteButton)
        val cancelButton: MaterialButton = view.findViewById(R.id.cancelButton)
        cancelButton.setOnClickListener {
            listener.onCompleted(mTotalPaste, copyStart)
            listener.onFileRefresh()
        }

        for (itemUri in fileList) {
            copiedItems.add(itemUri.file.getUri())
        }
        pasteButton.visibility = View.VISIBLE

        pasteButton.setOnClickListener {
            filePaste(requireContext(), copiedItems, explorerFragment.getCurrentPath())
        }
    }

    private fun filePaste(context: Context, copiedItems: MutableList<Uri>, destination: DocumentFile) {
        progressDialog.show()
        for (currentUri in copiedItems) {
            try {
                val copy: DocumentFile = DocumentFile.fromUri(context, currentUri)
                copyDoc(context, copy, destination)
                mTotalPaste++

                if (mTotalPaste == copiedItems.size) {
                    progressDialog.dismiss()
                    explorerFragment.refreshExplorer()
                } else {
                    explorerFragment.refreshExplorer()
                }
            } catch (e: FileNotFoundException) {
                showMessage(e)
            }
        }

    }

    private fun showMessage(e: Exception) {
        showMessage(e.message)
    }

    private fun showMessage(message: String?) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun copyDoc(context: Context, src: DocumentFile, path: DocumentFile?) {
        try {
            if (src.isDirectory()) {
                val createdDir = path!!.createDirectory(context, src.getName())
                val files = src.listFiles(context)
                for (file in files) {
                    try {
                        copyDoc(context, file, createdDir)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } else {
                copy(context, src, path)
            }
        } catch (e: Exception) {
            throw Exception(String.format("Error copying %s", "Files"))
        }
    }

    private fun copy(context: Context, src: DocumentFile, path: DocumentFile?) {

        //  String mime = mime(src.getUri().getPath());
        val file = path!!.createFile(context, src.getUri().path!!, src.getName())
        val resolver: ContentResolver = context.contentResolver
        val inputStream: InputStream? = resolver.openInputStream(src.getUri())
        val outputStream: OutputStream? = resolver.openOutputStream(file!!.getUri())
        if (inputStream == null || outputStream == null) throw IOException("Failed to open streams to start copying")
        val buffer = ByteArray(AppConfig.BUFFER_LENGTH_DEFAULT)
        var len = 0
        var lastRead = System.currentTimeMillis()
        while (len != -1) {
            if (inputStream.read(buffer).also { len = it } > 0) {
                outputStream.write(buffer, 0, len)
                outputStream.flush()
                lastRead = System.currentTimeMillis()
            }
            if (System.currentTimeMillis() - lastRead > AppConfig.DEFAULT_SOCKET_TIMEOUT) throw Exception(
                "Timed out or interrupted. Exiting!"
            )
        }
        outputStream.close()
        inputStream.close()
    }

    fun mime(URI: String): String? {
        var type: String? = null
        val extention = MimeTypeMap.getFileExtensionFromUrl(URI)
        if (extention != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extention)
        }
        return type
    }






    private val progressDialog by lazy {
        val view = layoutInflater.inflate(R.layout.layout_copy_move, null, false)
        val detailLayout = view.findViewById<RelativeLayout>(R.id.detailLayout)
        val progressLayout = view.findViewById<RelativeLayout>(R.id.progressLayout)

        detailLayout.visibility = View.GONE
        progressLayout.visibility = View.VISIBLE

        copyStart = true

        AlertDialog.Builder(requireActivity())
            .setTitle(R.string.copy_to)
            .setView(view)
            .setCancelable(false)
            .setNegativeButton(R.string.cancel, null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener {
                        dialog.dismiss()
                        explorerFragment.refreshExplorer()
                    }
                }
            }
    }

    interface Listener {
        fun onFileRefresh()

        fun onCompleted(fileSize: Int, status: Boolean)
    }
}